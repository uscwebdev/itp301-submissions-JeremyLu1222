import React from 'react';
import { useState } from 'react';

export default function FlightImg() {
  const [src, setSrc] = useState(
    'https://www.lufthansagroup.com/media/_processed_/7/8/csm_2389_07_0004_8f6dec2a3a.jpg'
  );

  const [alt, setAlt] = useState('787-9');

  const [caption, setCaption] = useState('Lufthansa 787-9');

  function changeImg(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div>
      <img className="picture" src={src} alt={alt} />
      <p id="caption">{caption}</p>

      <button
        className="button"
        onClick={() => {
          changeImg(
            'https://resources.globalair.com/specs/images/Boeing_787_8.jpg',
            '787-8',
            'British Airways 787-8'
          );
        }}
      >
        Show 787-8
      </button>

      <button
        className="button"
        onClick={() => {
          changeImg(
            'https://www.lufthansagroup.com/media/_processed_/7/8/csm_2389_07_0004_8f6dec2a3a.jpg',
            '787-9',
            'Lufthansa 787-9'
          );
        }}
      >
        Show 787-9
      </button>

      <button
        id="d"
        className="button"
        onClick={() => {
          changeImg(
            'https://upload.wikimedia.org/wikipedia/commons/c/c5/KLM_Royal_Dutch_Airlines_Boeing_787-10_Dreamliner_PH-BKA_%28100_Years_livery%29.jpg',
            'KLM787',
            'KLM 787-10'
          );
        }}
      >
        Show 787-10
      </button>

      <button
        className="button"
        onClick={() => {
          changeImg(
            'https://i.ytimg.com/vi/ksTEFo-ilF4/maxresdefault.jpg',
            'Vitenam 350',
            'Vietnam Airline A359'
          );
        }}
      >
        Show A350-900
      </button>

      <button
        className="button"
        onClick={() => {
          changeImg(
            'https://discovery.cathaypacific.com/wp-content/uploads/2018/07/Hero-CBC-1.jpg',
            'Cathay 351',
            'Cathay Pacific A350-1000'
          );
        }}
      >
        Show A350-1000
      </button>
    </div>
  );
}
