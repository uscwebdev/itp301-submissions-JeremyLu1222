import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import ProductImage from './ProductImage.js';

const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="header">
      <h1>Shopping Site</h1>
    </div>
    <div>
      <ProductImage />
    </div>
    <div id="footer">
      <p id="footertext">Jeremy Lu | Assignment 2</p>
    </div>
  </React.StrictMode>
);
