import React from 'react';
import Button from './AddItem.js';
import { useState } from 'react';
export default function Item(props) {
  const [subtotal, setSubtotal] = useState(0);
  function subtotaLPlus(i) {
    var plus = parseInt(i);
    setSubtotal(subtotal + plus);
  }
  function subtotalMinus(i) {
    var minus = parseInt(i);
    setSubtotal(subtotal - minus);
  }
  return (
    <div>
      <div id="itemSection">
        <Button
          src="https://static.nike.com/a/images/q_auto:eco/t_product_v1/f_auto/dpr_3.0/w_300,c_limit/96d8c051-f6d7-490f-9d5e-14846fbda52e/dunk-low-next-nature-womens-shoes-bxR0pv.png"
          alt="NikeDunk"
          name="Nike SB Dunk"
          price="230"
          parentPlus={subtotaLPlus}
          parentMinus={subtotalMinus}
        />

        <Button
          src="https://static.nike.com/a/images/q_auto:eco/t_product_v1/f_auto/dpr_3.0/w_300,c_limit/5615d881-6725-422a-b97b-82835fa62411/ja-1-wet-cement-basketball-shoes-bCx2W3.png"
          alt="NikeBasketball"
          name="Nike Ja 1"
          price="40"
          parentPlus={subtotaLPlus}
          parentMinus={subtotalMinus}
        />
        <Button
          src="https://vader-prod.s3.amazonaws.com/1684854258-image.png"
          alt="NikeRunning"
          name="Nike Alphafly 2 Carbon Plate"
          price="300"
          parentPlus={subtotaLPlus}
          parentMinus={subtotalMinus}
        />

        <Button
          src="https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1684434473-image.png?crop=0.852xw:0.852xh;0.0742xw,0.148xh&resize=980:*"
          alt="NikeRunning2"
          name="Nike Vaporfly 3 Carbon Plate"
          price="180"
          parentPlus={subtotaLPlus}
          parentMinus={subtotalMinus}
        />
      </div>
      <div className="row">
        <p className="subtotal">Subtotal: ${subtotal}</p>
      </div>
    </div>
  );
}
