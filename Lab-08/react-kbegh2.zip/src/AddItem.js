import React from 'react';
import { useState } from 'react';

export default function Button(props) {
  const [num, setNum] = useState(0);

  function handleNumPlus() {
    setNum(num + 1);
  }

  function handleNumMinus() {
    if (num > 0) {
      setNum(num - 1);
    }
  }
  return (
    <div>
      <div className="item">
        <img src={props.src} alt={props.caption} className="ItemPicture" />
        <p>{props.name}</p>
        <p className>{'$' + props.price}</p>
      </div>

      <div id="addsection">
        <button
          className="button"
          onClick={() => {
            handleNumMinus();
            if (num > 0) {
              props.parentMinus(props.price);
            }
          }}
        >
          -
        </button>
        <p>{num}</p>
        <button
          className="button"
          onClick={() => {
            handleNumPlus();
            props.parentPlus(props.price);
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
