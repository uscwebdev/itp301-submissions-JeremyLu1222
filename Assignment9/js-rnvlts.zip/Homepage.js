import React from 'react';
import './Homepage.css';
import { Link } from 'react-router-dom';
export default function HomePage() {
  return (
    <div className="background">
      <h1>YourPrivateJet</h1>
      <ul className="option">
        <li className="os">
          <Link to="/book" className="linkstyle">
            Book
          </Link>
        </li>
        <li className="os">
          <Link to="/about" className="linkstyle">
            About Us
          </Link>
        </li>
      </ul>
      <p id="intro">Spend Less, Enjoy More</p>
    </div>
  );
}
