import { Routes, Route } from 'react-router-dom';
import HomePage from './Homepage.js'; // Your HomePage component
import AboutPage from './AboutPage.js'; // Your AboutPage component
import BookPage from './Book.js'; // Your ContactPage component
import React from 'react';

function App() {
  return (
    <div>
      {/* Navigation can be placed here if you want */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/book" element={<BookPage />} />
        <Route path="/about" element={<AboutPage />} />
      </Routes>
    </div>
  );
}

export default App;
