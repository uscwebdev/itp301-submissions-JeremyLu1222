import React from 'react';
import './Aboutpage.css';
import { Link } from 'react-router-dom';
export default function AboutPage() {
  return (
    <div className="Info">
      <h2>Our Fleet</h2>
    <div className="gallery">
      <img className="Fleet" src="https://upload.wikimedia.org/wikipedia/commons/9/9b/2010-07-21_G550_NetJets_CS-DKE_EDDF_01.jpg" alt="G550"></img>
      <img className="Fleet" src="https://upload.wikimedia.org/wikipedia/commons/9/9b/2010-07-21_G550_NetJets_CS-DKE_EDDF_01.jpg" alt="G5502"></img>
      <img className="Fleet" src="https://upload.wikimedia.org/wikipedia/commons/9/9b/2010-07-21_G550_NetJets_CS-DKE_EDDF_01.jpg" alt="G5503"></img>
    

    </div>
        <h2>Our Services</h2>
      <div className="gallery2">
      <div className="des">
      <img className="Fleet" src="https://kevinsmithgroup.com/wp-content/uploads/2018/03/private-car-service.jpg" alt="Car"></img>
      <p className="intro">Private car</p>
      </div>
      <div className="des">
      <img className="Fleet" src="https://i.pinimg.com/736x/bf/af/5e/bfaf5e7eea511d50d1d9e015bdb25174.jpg" alt="Room"></img>
      <p className="intro">Private room</p>
      </div>
      <div className="des">
      <img className="Fleet" src="https://challengejetcharter.com/wp-content/uploads/2022/09/Private-Jet-Catering-1024x602.jpg" alt="Food"></img>
      <p className="intro">Delicious Food</p>
      </div>

    </div>

    </div>
  );
}