import React from 'react';
import ReactDOM from 'react-dom';
// import './index.css'; // Your global styles
import App from './app.js'; // Your main App component
import { BrowserRouter } from 'react-router-dom'; // Import BrowserRouter
const root = ReactDOM.createRoot(document.getElementById('root'));

// Wrap the <App /> in a <BrowserRouter> tag to enable routing
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
