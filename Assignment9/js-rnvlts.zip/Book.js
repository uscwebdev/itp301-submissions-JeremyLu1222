import React from 'react';
import './Book.css';
export default function BookPage() {
  return (
    <div className="Destination">
      <h2>Our Destinations</h2>
      <div id="booksection">
        <img
          className="destination"
          src="https://cdn.britannica.com/01/94501-050-7C939333/Big-Ben-London.jpg"
          alt="London"
        ></img>
        <div class="BlockSlider_list__2IAXE">
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Barcelona <span>(GRO)</span>
            </h6>
            <span class="u-small">Spain</span>
          </div>
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Ibiza <span>(IBZ)</span>
            </h6>
            <span class="u-small">Spain</span>
          </div>
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Cannes <span>(CEQ)</span>
            </h6>
            <span class="u-small">France</span>
          </div>
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Paris <span>(LBG)</span>
            </h6>
            <span class="u-small">France</span>
          </div>
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Paris <span>(CDG)</span>
            </h6>
            <span class="u-small">France</span>
          </div>
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Rome <span>(FCO)</span>
            </h6>
            <span class="u-small">Italy</span>
          </div>
          <div class="BlockSliderItem_item__2wFnq">
            <h6 class="BlockSliderItem_title__1MVdq">
              Amsterdam <span>(AMS)</span>
            </h6>
            <span class="u-small">Netherland</span>
          </div>
        </div>
      </div>
      <form>
        <div className="my-3 row">
          <label htmlFor="full-name" className="col-sm-2 col-form-label">
            Full Name: <span className="text-danger">*</span>
          </label>
          <div className="col-sm-10">
            <input
              type="text"
              className="form-control"
              placeholder="Tommy Trojan"
              id="full-name"
            />
          </div>
        </div>
        <div className="my-3 row">
          <label className="col-sm-2 col-form-label">
            Provide One: <span className="text-danger">*</span>
          </label>
          <div className="col-10">
            <div className="row">
              <label htmlFor="email" className="col-sm-2 col-form-label">
                Email:
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="ttrojan@usc.edu"
                  id="email"
                />
              </div>

              <label
                htmlFor="phone"
                className="mt-sm-2 col-sm-2 col-form-label"
              >
                Phone:
              </label>
              <div className="mt-sm-2 col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="(123) 456-7890"
                  id="phone"
                />
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
