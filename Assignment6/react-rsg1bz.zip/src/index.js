import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import ProductImage from './ProductImage.js';

const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="header">
      <h1>Shopping Site</h1>
    </div>
    <div id="itemSection">
      <ProductImage
        src="https://static.nike.com/a/images/q_auto:eco/t_product_v1/f_auto/dpr_3.0/w_300,c_limit/96d8c051-f6d7-490f-9d5e-14846fbda52e/dunk-low-next-nature-womens-shoes-bxR0pv.png"
        alt="NikeDunk"
        name="Nike SB Dunk"
        price="230"
      />
      <ProductImage
        src="https://static.nike.com/a/images/q_auto:eco/t_product_v1/f_auto/dpr_3.0/w_300,c_limit/5615d881-6725-422a-b97b-82835fa62411/ja-1-wet-cement-basketball-shoes-bCx2W3.png"
        alt="NikeBasketball"
        name="Nike Basketball Shoe"
        price="40"
      />
      <ProductImage
        src="https://vader-prod.s3.amazonaws.com/1684854258-image.png"
        alt="NikeRunning"
        name="Nike Alphafly 2 Carbon Plate Shoes"
        price="300"
      />

      <ProductImage
        src="https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1684434473-image.png?crop=0.852xw:0.852xh;0.0742xw,0.148xh&resize=980:*"
        alt="NikeRunning2"
        name="Nike Vaporfly 3 Carbon Plate Shoes"
        price="180"
      />
    </div>
    <div id="footer">
      <p id="footertext">Jeremy Lu | Assignment 2</p>
    </div>
  </React.StrictMode>
);
