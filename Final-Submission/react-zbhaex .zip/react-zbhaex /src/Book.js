import React from 'react';
import './Book.css';
import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function BookPage() {
  const [src, setSrc] = useState(
    'https://www.deutschland.de/sites/default/files/media/image/TdT_05032020_Frankfurt_Skyline.jpg'
  );
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [usernameError, setUsernameError] = useState('');
  const [EmailError, setEmailError] = useState('');
  const [Destination, setDestination] = useState(-1);
  const [DestinationError, setDestinationError] = useState('');
  const [Person, setPersron] = useState(-1);
  const [PersonError, setPersronError] = useState('');
  const [alt, setAlt] = useState('BCN');

  const handleMouseEnter = (newSrc, newAlt) => {
    setSrc(newSrc);
    setAlt(newAlt);
  };
  const [showModal, setShowModal] = useState(false);

  const toggleModal = () => {
    setShowModal(!showModal);
  };

  function handleSubmit(e) {
    var foundError = false;
    if (username.length == 0) {
      foundError = true;
      setUsernameError('Username cannot be empty.');
    } else if (
      username.indexOf(' ') == -1 ||
      username.indexOf(' ') == 0 ||
      username.lastIndexOf(' ') == username.length - 1
    ) {
      foundError = true;
      setUsernameError('You must provide a full name.');
    } else {
      // No errors.
      setUsernameError('');
    }
    if (email.length == 0) {
      foundError = true;
      setEmailError("Email can't be empty");
    }

    if (Destination == -1) {
      foundError = true;
      setDestinationError('Please select your destination');
    } else {
      setDestinationError('');
    }
    if (Person == -1) {
      foundError = true;
      setPersronError('Please add at least one person for your booking');
    } else {
      setPersronError('');
    }
    if (foundError == true) {
      // Have form validation errors.
      // Prevent it from submitting.
      e.preventDefault();
    } else {
      alert('Book Successful');
    }
  }

  return (
    <div className="container">
      <div id="titlesection">
        <p id="title">Our Destination </p>
        <div id="nav">
          <ul className="option1">
            <li className="os1">
              <Link to="/" className="linkstyle1">
                Home
              </Link>
            </li>
            <li className="os1">
              <Link to="/about" className="linkstyle1">
                About Us
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div id="booksection">
        <img className="image" src={src} alt={alt} />
        <div id="buttonSection1">
          <div class="Button">
            <button
              className="Dest"
              onMouseEnter={() =>
                handleMouseEnter(
                  'https://media.cntraveller.com/photos/62d14e029bbb08746e6fd952/master/pass/barcelonaGettyImages-1386922276.jpeg',
                  'BCN'
                )
              }
            >
              Barcelona(BCN) Spain
            </button>
            <h6 className="BlockSliderItem_title__1MVdq">
              Starting From $1000
            </h6>
          </div>
          <button
            className="Dest"
            onMouseEnter={() =>
              handleMouseEnter(
                'https://cdn.britannica.com/01/94501-050-7C939333/Big-Ben-London.jpg',
                'LHR'
              )
            }
          >
            London(LHR) UK
          </button>
          <h6 className="BlockSliderItem_title__1MVdq">Starting From $1300</h6>
          <button
            className="Dest"
            onMouseEnter={() =>
              handleMouseEnter(
                'https://media.cntraveller.com/photos/6220bfe35e6084e5d4f02404/4:3/w_5120,h_3840,c_limit/Seine%20paris%20bike-GettyImages-1161606501.jpeg',
                'CDG'
              )
            }
          >
            Paris(CDG) France
          </button>
          <h6 className="BlockSliderItem_title__1MVdq">Starting From $800</h6>
          <button
            className="Dest"
            onMouseEnter={() =>
              handleMouseEnter(
                'https://media.gq-magazine.co.uk/photos/5d139922b363fa43f120ce07/4:3/w_1704,h_1278,c_limit/Nyhavn-1-gq--4jan17_alamy_b.jpg',
                'CPH'
              )
            }
          >
            Copenhagen(CPH),Denmark
          </button>
          <h6 className="BlockSliderItem_title__1MVdq">Starting From $1200</h6>
          <button
            className="Dest"
            onMouseEnter={() =>
              handleMouseEnter(
                'https://media.timeout.com/images/105303515/image.jpg',
                'BER'
              )
            }
          >
            Berlin(BER),Germany
          </button>
          <h6 className="BlockSliderItem_title__1MVdq">Starting From $900</h6>
          <div id="buttonsection">
            <button className="BookFormBut" onClick={toggleModal}>
              Book Now
            </button>
            {showModal && (
              <div className="modal">
                <div className="modal-content">
                  <span className="close" onClick={toggleModal}>
                    &times;
                  </span>
                  <form onSubmit={handleSubmit}>
                    <div>
                      <input
                        type="text"
                        placeholder="Name"
                        className="form-control"
                        onChange={(e) => {
                          console.log(e.currentTarget.value);
                          setUsername(e.currentTarget.value);
                        }}
                        value={username}
                      />

                      <small className="Error">{usernameError}</small>
                    </div>
                    <div>
                      <input
                        type="email"
                        placeholder="Email"
                        className="form-control"
                        onChange={(e) => {
                          console.log(e.currentTarget.value);
                          setEmail(e.currentTarget.value);
                        }}
                        value={email}
                      />
                      <small className="Error">{EmailError}</small>
                    </div>
                    <div className="col-sm-10">
                      <select
                        onChange={(e) => {
                          setDestination(e.currentTarget.value);
                        }}
                        value={Destination}
                        className="form-control"
                        id="destinationform"
                      >
                        <option value="-1" disabled>
                          -- Select One --
                        </option>
                        <option value="freshman">Barcelona</option>
                        <option value="sophomore">London</option>
                        <option value="junior">Copenhagen</option>
                        <option value="senior">Berlin</option>
                      </select>

                      <small id="class-error" className="Error">
                        {DestinationError}
                      </small>
                    </div>
                    <div className="col-sm-10">
                      <select
                        onChange={(e) => {
                          setPersron(e.currentTarget.value);
                        }}
                        value={Person}
                        className="form-control"
                        id="Personform"
                      >
                        <option value="-1" disabled>
                          0
                        </option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                      </select>

                      <small id="class-error" className="Error">
                        {PersonError}
                      </small>
                    </div>
                    <button type="submit">Submit</button>
                  </form>
                </div>
              </div>
            )}
          </div>
          <h6 className="Reminder">*Price may change due to seasons</h6>
        </div>
      </div>
    </div>
  );
}
