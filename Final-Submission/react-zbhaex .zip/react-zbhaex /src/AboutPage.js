import React from 'react';
import './Aboutpage.css';
import { Link } from 'react-router-dom';
import { useState } from 'react';

export default function AboutPage() {
  const [hoverText, setHoverText] = useState('');

  const handleMouseEnter = (text) => {
    setHoverText(text);
  };

  const handleMouseLeave = () => {
    setHoverText('');
  };
  const [showModal1, setShowModal1] = useState(false);
  const [showModal2, setShowModal2] = useState(false);
  const [showModal3, setShowModal3] = useState(false);
  const [showModal4, setShowModal4] = useState(false);

  const toggleModal1 = () => {
    setShowModal1(!showModal1); // This toggles the state of showModal1
  };
  const toggleModal2 = () => {
    setShowModal2(!showModal2); // This toggles the state of showModal1
  };
  const toggleModal3 = () => {
    setShowModal3(!showModal3); // This toggles the state of showModal1
  };
  const toggleModal4 = () => {
    setShowModal4(!showModal4); // This toggles the state of showModal1
  };
  return (
    <div className="Info">
      <div id="titlesection1">
        <p className="title1">Our Fleet</p>
        <div id="nav1">
          <ul className="option1">
            <li className="os1">
              <Link to="/" className="linkstyle1">
                Home
              </Link>
            </li>
            <li className="os1">
              <Link to="/book" className="linkstyle1">
                Book
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="gallery">
        <div className="tooltip-container" onMouseLeave={handleMouseLeave}>
          <img
            className="tooltip"
            src="https://upload.wikimedia.org/wikipedia/commons/9/9b/2010-07-21_G550_NetJets_CS-DKE_EDDF_01.jpg"
            alt="G550"
            onMouseEnter={() => handleMouseEnter('Gulfstream G550')}
          />
          {hoverText === 'Gulfstream G550' && (
            <span className="tooltiptext">{hoverText}</span>
          )}
        </div>
        <div className="tooltip-container" onMouseLeave={handleMouseLeave}>
          <img
            className="tooltip"
            src="https://www.iflyplus.com/photo/pro/model/%E5%BA%9E%E5%B7%B4%E8%BF%AA%E6%8C%91%E6%88%98%E8%80%85850.001.jpeg"
            alt="G5502"
            onMouseEnter={() => handleMouseEnter('Challenger 850')}
          />
          {hoverText === 'Challenger 850' && (
            <span className="tooltiptext">{hoverText}</span>
          )}
        </div>
        <div className="tooltip-container" onMouseLeave={handleMouseLeave}>
          <img
            className="tooltip"
            src="https://bjtonline.com/sites/default/files/aircraft/l450_exterior_1_marked.jpg"
            alt="G5503"
            onMouseEnter={() => handleMouseEnter('Legacy 450')}
          />
          {hoverText === 'Legacy 450' && (
            <span className="tooltiptext">{hoverText}</span>
          )}
        </div>
        <div className="tooltip-container" onMouseLeave={handleMouseLeave}>
          <img
            className="tooltip"
            src="https://www.jetcraft.com/wp-content/uploads/2023/05/Learjet-60XR-sn-362_ext1_wm.jpg"
            alt="G5504"
            onMouseEnter={() => handleMouseEnter('Learjet 60XR')}
          />
          {hoverText === 'Learjet 60XR' && (
            <span className="tooltiptext">{hoverText}</span>
          )}
        </div>
      </div>
      <p className="title2">Our Services</p>
      <div className="service1">
        <img
          className="Service"
          src="https://suvchicagolimo.com/wp-content/uploads/2016/10/private-car-and-driver-service.jpg"
          alt="Food"
        />
        <img
          className="Service"
          src="https://i.pinimg.com/736x/bf/af/5e/bfaf5e7eea511d50d1d9e015bdb25174.jpg"
          alt="Food"
        />
        <img
          className="Service"
          src="https://challengejetcharter.com/wp-content/uploads/2022/09/Private-Jet-Catering-1024x602.jpg"
          alt="Food"
        />
        <img
          className="Service"
          src="https://airportinternational.com.au/wp-content/uploads/2021/04/london-aiport-1.jpg"
          alt="Food"
        />
      </div>
      <div className="service1">
        <div id="intro1">
          <h2 className="intro" onClick={toggleModal1}>
            Private pickup services to airport
          </h2>
          {showModal1 && (
            <div className="modal1">
              <div className="modal-content1">
                <span className="close" onClick={toggleModal1}>
                  &times;
                </span>
                <p className="introtext">
                  A premium airport pickup service ensures a seamless and
                  stress-free start to your journey. Upon arrival, you're
                  greeted by a professional chauffeur holding a sign with your
                  name, ready to assist with your luggage and escort you to a
                  luxury vehicle. The plush interiors, coupled with the
                  convenience of a pre-planned route, guarantee relaxation and
                  punctuality. As you travel, amenities such as climate control,
                  bottled water, and Wi-Fi contribute to a comfortable and
                  connected ride. This service is ideal for business travelers,
                  tourists, or anyone preferring an efficient and luxurious
                  transition to their next destination.
                </p>
              </div>
            </div>
          )}
        </div>
        <div id="intro1">
          <div className="introsection">
            <h2 className="intro" onClick={toggleModal2}>
              Private Airport Waiting Room
            </h2>
          </div>
          {showModal2 && (
            <div className="modal1">
              <div className="modal-content1">
                <span className="close" onClick={toggleModal2}>
                  &times;
                </span>
                <p className="introtext">
                  A private airport waiting room offers a tranquil haven away
                  from the bustling airport crowds. Designed for comfort and
                  convenience, it typically features luxurious seating,
                  complimentary high-speed Wi-Fi, and a range of refreshments.
                  Passengers can relax in a serene environment, often with
                  access to exclusive services like concierge and real-time
                  flight information. These waiting rooms provide a peaceful
                  workspace for business travelers, as well as a cozy retreat
                  for leisure passengers awaiting their flights, ensuring a
                  premium travel experience with privacy and personalized
                  attention.
                </p>
              </div>
            </div>
          )}
        </div>
        <div id="intro1">
          <div className="introsection1">
            <h2 className="intro" onClick={toggleModal3}>
              Fine Dinning on abroad{' '}
            </h2>
          </div>
          {showModal3 && (
            <div className="modal1">
              <div className="modal-content1">
                <span className="close" onClick={toggleModal3}>
                  &times;
                </span>
                <p className="introtext">
                  Experiencing fine dining onboard an aircraft elevates the
                  journey to a memorable culinary adventure. In the intimate
                  confines of a cabin, passengers indulge in gourmet dishes
                  curated by renowned chefs, paired with a selection of fine
                  wines and champagnes. The ambiance is meticulously crafted
                  with elegant tableware and linens, complemented by attentive
                  service. This exclusive dining experience is marked by its
                  personalized menu options, catering to various dietary
                  preferences and cultural tastes. As the landscapes change
                  below, the flavors and textures on offer create a sensory
                  delight, making the flight not just a travel necessity but a
                  gastronomic event to savor.
                </p>
              </div>
            </div>
          )}
        </div>
        <div id="intro1">
          <div className="introsection2">
            <h2 className="intro" onClick={toggleModal4}>
              Arrival Services
            </h2>
          </div>
          {showModal4 && (
            <div className="modal1">
              <div className="modal-content1">
                <span className="close" onClick={toggleModal4}>
                  &times;
                </span>
                <p className="introtext">
                  Arrival services streamline your entry into a new city,
                  ensuring a smooth transition from air to ground. Upon landing,
                  a representative greets you, assisting with navigation through
                  the airport complexities. They expedite processes like
                  immigration, baggage claim, and customs, minimizing wait times
                  and hassle. Whether providing a porter for your luggage or
                  arranging a luxury car to your destination, these services
                  cater to your convenience. Tailored for business travelers
                  needing efficiency or vacationers seeking a stress-free start,
                  arrival services transform your first steps into a seamless,
                  personalized experience, setting a comforting tone for the
                  entirety of your stay.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
