import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [username, setUsername] = useState('');
  const [Password, setPassword] = useState('');
  const [Confirm, setConfirm] = useState('');
  const [correct, setCorrect] = useState('false');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [CommentCount, setCommentCount] = useState(0);
  const [Accept, setAccept] = useState(false);

  const [usernameError, setUsernameError] = useState();
  const [PasswordError, setPasswordError] = useState();
  const [CofirmError, setConfirmError] = useState();
  const [EmailPhoneError, setEmailPhoneError] = useState();
  const [CommentError, setCommentError] = useState();
  const [AcceptError, setAcceptError] = useState();

  function handleSubmit(e) {
    // e.preventDefault();
    // console.log('form submitted');

    var foundError = false;

    /*
      Username cannot be empty.
      Username cannot contain uppercase letters.
    */
    if (username.length == 0) {
      // Username is empty.
      foundError = true;
      setUsernameError('Username cannot be empty.');
    } else if (
      username.indexOf(' ') == -1 ||
      username.indexOf(' ') == 0 ||
      username.lastIndexOf(' ') == username.length - 1
    ) {
      // Username contains uppercase characters.
      foundError = true;
      setUsernameError('You must provide a full name.');
    } else {
      // No errors.
      setUsernameError('');
    }
    if (Password.length == 0) {
      // Username is empty.
      foundError = true;
      setPasswordError('Password cannot be empty.');
    } else if (Password.length < 5) {
      // Username is empty.
      foundError = true;
      setPasswordError('Password must contain at least 5 characters.');
    } else if (!(/[A-Z]/.test(Password) && /[a-z]/.test(Password))) {
      foundError = true;
      setPasswordError(
        'Password must contain uppercase and lowercase characters.'
      );
    } else {
      setPasswordError('');
    }
    if (Confirm !== Password) {
      foundError = true;
      setConfirmError('Passwords do not match.');
    } else {
      setConfirmError('');
    }
    if (!email && !phone) {
      foundError = true;
      setEmailPhoneError('You must provide either email or phone.');
    } else {
      setEmailPhoneError('');
    }

    if (comment.length > 100) {
      foundError = true;
      setCommentError('Comments cannot exceed 100 characters.');
    } else {
      setCommentError();
    }

    if (Accept == false) {
      foundError = true;
      setAcceptError('You must accept Terms & Conditions.');
    } else {
      setAcceptError('');
    }

    if (foundError == true) {
      // Have form validation errors.
      // Prevent it from submitting.
      e.preventDefault();
    } else {
      alert('Registration Successful');
    }
  }
  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setUsername(e.currentTarget.value);
                  }}
                  value={username}
                />
                <small id="username-error" className="form-text text-danger">
                  {usernameError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setPassword(e.currentTarget.value);
                  }}
                  value={Password}
                />
                <small id="Password-error" className="form-text text-danger">
                  {PasswordError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setConfirm(e.currentTarget.value);
                  }}
                  value={Confirm}
                />
                <small id="Confirm-error" className="form-text text-danger">
                  {CofirmError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      onChange={(e) => {
                        console.log(e.currentTarget.value);
                        setEmail(e.currentTarget.value);
                      }}
                      value={email}
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      onChange={(e) => {
                        console.log(e.currentTarget.value);
                        setPhone(e.currentTarget.value);
                      }}
                      value={phone}
                    />
                  </div>
                </div>
                <small id="EmailPhone-error" className="form-text text-danger">
                  {EmailPhoneError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  onChange={(e) => {
                    setComment(e.currentTarget.value);
                    setCommentCount(e.currentTarget.value.length);
                  }}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {CommentCount} / 100
                </small>
              </div>
              <small id="text-error" className="form-text text-danger">
                  {CommentError}
                </small>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    onChange={() => {
                      setAccept(!Accept);
                    }}
                    Accept={true}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
              <small id="Accept-error" className="form-text text-danger">
                {AcceptError}
              </small>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
