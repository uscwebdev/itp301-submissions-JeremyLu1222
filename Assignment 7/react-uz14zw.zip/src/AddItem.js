import React from 'react';
import { useState } from 'react';

export default function CountButton() {
  const [count, setCount] = useState(0);
  function CountButton(sign) {
    if (sign == '+') {
      setCount(count + 1);
    }
    if (sign == '-' && count != 0) {
      setCount(count - 1);
    }
  }
  return (
    <div id="addsection">
      <button
        className="button"
        onClick={() => {
          CountButton('+');
        }}
      >
        +
      </button>
      <p id="countnum">{count}</p>

      <button
        className="button"
        onClick={() => {
          CountButton('-');
        }}
      >
        -
      </button>
    </div>
  );
}
