import React from 'react';
import CountButton from './AddItem.js';
export default function ProductImage(props) {
  return (
    <div className="item">
      <img src={props.src} alt={props.alt} className="ItemPicture" />
      <p className="price">
        {props.name}: ${props.price}
      </p>
      <CountButton />
    </div>
  );
}
