import React from 'react';
//export default makes this public global functioan that is accessable to other files.

export default function UserProfile(props) {
  return(
  <div className="user">
    <img
      src={props.src}
      alt="userprofilepic"
      className="useravatar"
    />
    <p className="username">{props.name}</p>
    
    <b><p className="comment">{props.comment}</p></b>
    <p className="date"><em>{props.date}</em></p>
  </div>
  );
}